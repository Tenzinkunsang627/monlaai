# BodLingo — Architecture & Development Plan

> A Duolingo-style Tibetan language learning web app powered by **Monlam AI APIs**.
> **MVP scope:** 2 days. **Auth:** single default profile (no login). **Content:** pre-seeded in SQLite; Monlam TTS/STT/Dictionary/Translation called live.

**Stack:** React + Tailwind CSS (frontend) · FastAPI (Python backend) · SQLite (DB)

---

## 0. High-Level Overview

```
┌─────────────────────────────────────────────────────────────┐
│                         BROWSER (SPA)                         │
│  React + Tailwind  ·  React Router  ·  Zustand (state)        │
│  Web Audio / MediaRecorder for mic + audio playback          │
└───────────────▲───────────────────────────┬──────────────────┘
                │ REST (JSON, multipart)     │
                │                            ▼
┌───────────────┴───────────────────────────────────────────────┐
│                        FastAPI BACKEND                          │
│  Routers → Services → Repositories (SQLAlchemy)                 │
│  MonlamClient (httpx) → TTS / STT / Dictionary / Translation    │
└───────────────┬───────────────────────────────────────────────┘
                │
        ┌───────┴────────┐            ┌──────────────────────────┐
        │  SQLite (DB)   │            │   Monlam AI API (cloud)  │
        └────────────────┘            └──────────────────────────┘
```

---

## 1. Complete Folder Structure

```
bodlingo/
├── README.md
├── ARCHITECTURE.md
├── docker-compose.yml                 # optional: runs api + web together
│
├── backend/
│   ├── .env.example                   # MONLAM_API_KEY, MONLAM_BASE_URL, etc.
│   ├── requirements.txt
│   ├── Dockerfile
│   ├── alembic.ini                    # (optional) migrations
│   ├── pytest.ini
│   ├── app/
│   │   ├── main.py                    # FastAPI app factory, CORS, router mount
│   │   ├── config.py                  # Settings via pydantic-settings
│   │   ├── database.py                # engine, SessionLocal, Base, get_db()
│   │   │
│   │   ├── models/                    # SQLAlchemy ORM models
│   │   │   ├── __init__.py
│   │   │   ├── user.py                # single default profile
│   │   │   ├── alphabet.py
│   │   │   ├── lesson.py              # Lesson, Vocabulary
│   │   │   ├── exercise.py            # Exercise (listening/speaking/quiz)
│   │   │   ├── quiz.py                # Quiz, Question, Option
│   │   │   └── progress.py            # UserProgress, XPLog, ExerciseAttempt
│   │   │
│   │   ├── schemas/                    # Pydantic request/response DTOs
│   │   │   ├── __init__.py
│   │   │   ├── alphabet.py
│   │   │   ├── lesson.py
│   │   │   ├── exercise.py
│   │   │   ├── quiz.py
│   │   │   ├── progress.py
│   │   │   └── monlam.py              # TTS/STT/Dictionary/Translate DTOs
│   │   │
│   │   ├── routers/                    # API endpoints (thin controllers)
│   │   │   ├── __init__.py
│   │   │   ├── alphabet.py
│   │   │   ├── lessons.py
│   │   │   ├── exercises.py
│   │   │   ├── quiz.py
│   │   │   ├── progress.py
│   │   │   ├── speech.py              # TTS + STT proxy
│   │   │   └── dictionary.py          # dictionary + translation proxy
│   │   │
│   │   ├── services/                   # business logic
│   │   │   ├── __init__.py
│   │   │   ├── alphabet_service.py
│   │   │   ├── lesson_service.py
│   │   │   ├── exercise_service.py
│   │   │   ├── quiz_service.py
│   │   │   ├── progress_service.py    # XP rules, streaks, level-ups
│   │   │   ├── speech_service.py      # STT scoring, TTS caching
│   │   │   └── monlam_client.py       # httpx wrapper for all Monlam calls
│   │   │
│   │   ├── repositories/               # DB access layer (CRUD)
│   │   │   ├── __init__.py
│   │   │   ├── alphabet_repo.py
│   │   │   ├── lesson_repo.py
│   │   │   ├── quiz_repo.py
│   │   │   └── progress_repo.py
│   │   │
│   │   ├── core/
│   │   │   ├── __init__.py
│   │   │   ├── xp_rules.py            # XP constants & level thresholds
│   │   │   ├── errors.py              # custom exceptions + handlers
│   │   │   └── audio_cache.py         # TTS mp3 cache on disk
│   │   │
│   │   └── seed/
│   │       ├── __init__.py
│   │       ├── seed_data.py           # loads JSON fixtures into DB
│   │       ├── alphabet.json          # 30 consonants + 4 vowels
│   │       ├── vocabulary.json        # themed word lists
│   │       └── quizzes.json           # quiz banks per lesson
│   │
│   ├── media/
│   │   └── tts_cache/                 # cached TTS audio files
│   │
│   └── tests/
│       ├── conftest.py
│       ├── test_progress.py
│       ├── test_quiz.py
│       └── test_monlam_client.py
│
└── frontend/
    ├── .env.example                   # VITE_API_BASE_URL
    ├── package.json
    ├── vite.config.js
    ├── tailwind.config.js
    ├── postcss.config.js
    ├── index.html
    └── src/
        ├── main.jsx
        ├── App.jsx                    # router + layout shell
        ├── index.css                 # tailwind directives + theme
        │
        ├── api/                        # typed API client (axios/fetch)
        │   ├── client.js
        │   ├── alphabet.js
        │   ├── lessons.js
        │   ├── exercises.js
        │   ├── quiz.js
        │   ├── progress.js
        │   ├── speech.js
        │   └── dictionary.js
        │
        ├── store/                      # Zustand stores
        │   ├── useProgressStore.js
        │   └── useUiStore.js
        │
        ├── hooks/
        │   ├── useAudioPlayer.js       # play TTS / lesson audio
        │   ├── useRecorder.js          # MediaRecorder → blob for STT
        │   └── useToast.js
        │
        ├── components/                 # reusable UI
        │   ├── layout/
        │   │   ├── Navbar.jsx
        │   │   ├── Sidebar.jsx
        │   │   └── PageContainer.jsx
        │   ├── common/
        │   │   ├── Button.jsx
        │   │   ├── Card.jsx
        │   │   ├── ProgressBar.jsx
        │   │   ├── XPBadge.jsx
        │   │   ├── StreakFlame.jsx
        │   │   ├── Modal.jsx
        │   │   └── Loader.jsx
        │   ├── audio/
        │   │   ├── PlayButton.jsx      # TTS playback
        │   │   └── RecordButton.jsx    # STT capture
        │   └── exercise/
        │       ├── AlphabetTile.jsx
        │       ├── VocabCard.jsx
        │       ├── ListeningCard.jsx
        │       ├── SpeakingCard.jsx
        │       ├── QuizQuestion.jsx
        │       └── FeedbackBanner.jsx  # correct/incorrect + XP gained
        │
        ├── pages/                      # route-level screens
        │   ├── HomePage.jsx
        │   ├── AlphabetPage.jsx
        │   ├── LessonsPage.jsx         # lesson list
        │   ├── VocabularyLessonPage.jsx
        │   ├── ListeningPage.jsx
        │   ├── SpeakingPage.jsx
        │   ├── QuizPage.jsx
        │   ├── ResultPage.jsx          # session summary + XP
        │   └── ProgressPage.jsx        # XP, level, streak, history
        │
        └── utils/
            ├── constants.js
            ├── formatters.js
            └── scoring.js              # client-side helpers
```

---

## 2. Database Schema (SQLite)

Single-user MVP: one row in `users` (id=1) acts as the default profile.

```
users
  id            INTEGER PK
  display_name  TEXT      default 'Learner'
  total_xp      INTEGER   default 0
  level         INTEGER   default 1
  streak_days   INTEGER   default 0
  last_active   DATE
  created_at    DATETIME

alphabet
  id            INTEGER PK
  char          TEXT        # e.g. ཀ
  romanization  TEXT        # 'ka'
  ipa           TEXT        # optional phonetic
  type          TEXT        # 'consonant' | 'vowel'
  order_index   INTEGER
  example_word  TEXT
  example_meaning TEXT

lessons
  id            INTEGER PK
  title         TEXT
  description   TEXT
  category      TEXT        # 'vocabulary' | 'listening' | 'speaking'
  level         INTEGER     # difficulty / unlock order
  order_index   INTEGER
  icon          TEXT

vocabulary
  id            INTEGER PK
  lesson_id     INTEGER FK -> lessons.id
  tibetan       TEXT        # བཀྲ་ཤིས་བདེ་ལེགས
  romanization  TEXT
  english       TEXT
  audio_url     TEXT NULL   # optional pre-cached / else live TTS
  order_index   INTEGER

exercises
  id            INTEGER PK
  lesson_id     INTEGER FK -> lessons.id
  type          TEXT        # 'listening' | 'speaking' | 'match'
  prompt_tibetan TEXT NULL
  prompt_english TEXT NULL
  expected_text TEXT NULL   # target for STT comparison
  xp_reward     INTEGER default 10
  order_index   INTEGER

quizzes
  id            INTEGER PK
  lesson_id     INTEGER FK -> lessons.id NULL
  title         TEXT
  xp_reward     INTEGER default 20

questions
  id            INTEGER PK
  quiz_id       INTEGER FK -> quizzes.id
  type          TEXT        # 'mcq' | 'audio_mcq' | 'translate'
  prompt        TEXT
  prompt_audio  TEXT NULL   # tibetan text to TTS
  correct_option_id INTEGER # set after options exist
  order_index   INTEGER

options
  id            INTEGER PK
  question_id   INTEGER FK -> questions.id
  text          TEXT
  is_correct    INTEGER (bool)

-- Progress tracking --

user_progress
  id            INTEGER PK
  user_id       INTEGER FK -> users.id
  lesson_id     INTEGER FK -> lessons.id
  status        TEXT        # 'not_started' | 'in_progress' | 'completed'
  score_percent INTEGER default 0
  completed_at  DATETIME NULL
  UNIQUE(user_id, lesson_id)

exercise_attempts
  id            INTEGER PK
  user_id       INTEGER FK -> users.id
  exercise_id   INTEGER FK NULL
  question_id   INTEGER FK NULL
  is_correct    INTEGER (bool)
  stt_confidence REAL NULL   # for speaking scoring
  created_at    DATETIME

xp_log
  id            INTEGER PK
  user_id       INTEGER FK -> users.id
  source        TEXT        # 'quiz' | 'listening' | 'speaking' | 'vocab'
  amount        INTEGER
  created_at    DATETIME
```

**Relationships (summary)**
- `lessons 1─* vocabulary`, `lessons 1─* exercises`, `lessons 1─* quizzes`
- `quizzes 1─* questions 1─* options`
- `users 1─* user_progress / exercise_attempts / xp_log`

---

## 3. API Architecture (FastAPI REST)

Base URL: `/api`. All responses JSON unless noted.

### Content
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/alphabet` | List all letters (consonants + vowels) |
| GET | `/api/alphabet/{id}` | Single letter detail |
| GET | `/api/lessons` | List lessons (filter by `?category=`) |
| GET | `/api/lessons/{id}` | Lesson detail + vocabulary + exercises |
| GET | `/api/lessons/{id}/vocabulary` | Vocab items for a lesson |

### Exercises
| GET | `/api/exercises/{lesson_id}` | Exercises for lesson |
| POST | `/api/exercises/{id}/attempt` | Submit an attempt → returns correctness + XP |

### Quiz
| GET | `/api/quizzes` | List quizzes |
| GET | `/api/quizzes/{id}` | Quiz with questions + options (no answer key leaked) |
| POST | `/api/quizzes/{id}/submit` | Submit answers → score, correct answers, XP |

### Progress / XP
| GET | `/api/progress` | Full user profile: total_xp, level, streak, per-lesson status |
| POST | `/api/progress/complete` | Mark lesson complete → award XP, update streak |
| GET | `/api/progress/xp-log` | Recent XP history |

### Monlam-backed (proxy) endpoints
| POST | `/api/speech/tts` | `{ text }` → returns audio (mp3) or cached URL |
| POST | `/api/speech/stt` | multipart audio → `{ transcript, confidence }` |
| POST | `/api/speech/score` | audio + `expected_text` → `{ is_correct, similarity, transcript }` |
| GET | `/api/dictionary?word=` | Dictionary lookup (Monlam) |
| POST | `/api/translate` | `{ text, src, tgt }` → translation (if API available) |

**Cross-cutting:** CORS for the Vite dev origin, centralized error handler, request logging, and a `GET /api/health` check. Monlam key stays server-side only (frontend never sees it).

---

## 4. Frontend Architecture

- **Routing (React Router):**
  `/` Home · `/alphabet` · `/lessons` · `/lessons/:id` (vocab) · `/listening/:lessonId` · `/speaking/:lessonId` · `/quiz/:id` · `/result` · `/progress`
- **State (Zustand):**
  - `useProgressStore` — total XP, level, streak, per-lesson status; hydrated from `/api/progress` on load; optimistic updates after attempts.
  - `useUiStore` — modals, toasts, loading flags.
- **Data layer:** thin modules in `src/api/*` wrapping a shared `client.js` (base URL, error interceptor). Components call these, never `fetch` directly.
- **Audio:**
  - `useAudioPlayer` plays TTS/vocab audio (from `/api/speech/tts` or cached `audio_url`).
  - `useRecorder` uses `MediaRecorder` → uploads blob to `/api/speech/score` for speaking exercises.
- **Design system:** Tailwind theme (rounded cards, playful accent colors, XP green, streak orange), reusable `Button/Card/ProgressBar/XPBadge/StreakFlame`, mobile-first responsive, dark-mode ready.
- **Feedback loop:** every exercise ends with `FeedbackBanner` (correct/incorrect + XP gained), then updates the progress store and animates the XP bar.

---

## 5. Backend Architecture (layered)

```
Router (HTTP/validation)  →  Service (business logic)  →  Repository (DB)
                                     │
                                     └→ MonlamClient (external API)
```

- **Routers** — thin; parse/validate with Pydantic, call services, shape responses.
- **Services** — all rules live here:
  - `progress_service`: XP awarding, level thresholds, streak increment (once per day via `last_active`).
  - `quiz_service`: grade submissions, prevent answer-key leakage on GET.
  - `speech_service`: call Monlam STT, compute similarity vs `expected_text` (normalized Tibetan + Levenshtein/ratio), decide `is_correct`; cache TTS output.
- **`monlam_client`** — single `httpx.AsyncClient` wrapper with retries, timeouts, auth header injection, and typed methods: `tts()`, `stt()`, `dictionary()`, `translate()`.
- **Repositories** — SQLAlchemy CRUD, keep services DB-agnostic.
- **Core** — `xp_rules.py` (constants), `errors.py` (exception→HTTP mapping), `audio_cache.py` (hash text → mp3 on disk, serve from `/media`).
- **Seed** — `seed_data.py` idempotently loads `alphabet.json`, `vocabulary.json`, `quizzes.json` on first run.

**XP rules (initial):** vocab item viewed = 2 XP, listening correct = 10, speaking correct = 15, quiz question correct = 5, lesson complete bonus = 20. Level up every 100 XP.

---

## 6. Component Diagram

```
                         ┌────────────────────────────┐
                         │           App.jsx           │
                         │  Navbar · Sidebar · Router  │
                         └──────────────┬──────────────┘
        ┌──────────────┬───────────────┼───────────────┬───────────────┐
        ▼              ▼               ▼               ▼               ▼
   HomePage      AlphabetPage     LessonsPage     ListeningPage    SpeakingPage
      │               │           │        │           │               │
 XPBadge/Streak  AlphabetTile  LessonCard  VocabCard  ListeningCard  SpeakingCard
 ProgressBar     PlayButton              PlayButton   PlayButton     RecordButton
                                                      FeedbackBanner FeedbackBanner
        │                                                   │
        ▼                                                   ▼
                 ┌───────────────── QuizPage ─────────────────┐
                 │  QuizQuestion → options → FeedbackBanner    │
                 └─────────────────────────────────────────────┘
                                    │
                                    ▼
                       ResultPage / ProgressPage (XP, level, streak, history)

State:  useProgressStore  ◄──hydrate/update──►  api/* modules  ──►  FastAPI
Audio:  useAudioPlayer (TTS)  ·  useRecorder (STT)
```

**Backend components**

```
main.py ─ mounts routers
  ├─ alphabet/lessons/exercises/quiz/progress routers ─► services ─► repositories ─► SQLite
  └─ speech/dictionary routers ─► speech_service/monlam_client ─► Monlam AI API
                                          └─ audio_cache (media/tts_cache)
```

---

## 7. Development Roadmap — 5 Developers in Parallel (2 Days)

**Shared Day-0 kickoff (first ~1–2h, together):** agree on the API contract in this doc, scaffold `backend/` + `frontend/`, commit the DB models & Pydantic schemas as the shared contract, and stub every endpoint so frontend can integrate against mocks immediately.

| Dev | Owns | Day 1 | Day 2 |
|---|---|---|---|
| **Dev A — Backend Core & DB** | models, database, repositories, seed data, progress/XP service | Build all SQLAlchemy models, `database.py`, seed JSON + loader, progress & XP/streak service + tests | Harden quiz grading, XP log endpoint, progress endpoints; polish + tests |
| **Dev B — Monlam Integration** | `monlam_client`, speech & dictionary routers/services, audio cache | Implement TTS + STT clients, `/speech/tts`, `/speech/stt`, disk cache | STT similarity scoring `/speech/score`, dictionary + translate endpoints, retries/timeouts, tests |
| **Dev C — Frontend Foundation & Content** | App shell, routing, Tailwind theme, design system, Home/Alphabet/Lessons pages | Scaffold Vite+Tailwind, Navbar/Sidebar/layout, common components, HomePage, AlphabetPage w/ tiles | LessonsPage + VocabularyLessonPage with VocabCard + PlayButton wired to TTS |
| **Dev D — Interactive Exercises** | listening, speaking, quiz pages + audio hooks | `useAudioPlayer`, `useRecorder`, ListeningPage + ListeningCard | SpeakingPage (record→score), QuizPage + QuizQuestion + submit flow, FeedbackBanner |
| **Dev E — Progress, State & Integration** | Zustand stores, api client modules, ProgressPage, ResultPage, glue/QA | `api/*` client modules + `client.js`, `useProgressStore`, ProgressPage (XP/level/streak) | ResultPage, wire XP updates across all exercises, end-to-end QA, bug bash, README/deploy |

**Dependency management (so no one blocks):**
- The **API contract (Sections 2 & 3)** is frozen at kickoff → frontend devs (C, D, E) build against stubbed/mock responses while A & B implement real logic.
- Dev E owns the `api/*` layer, so C & D consume typed functions rather than raw endpoints.
- Integration checkpoints: **end of Day 1** (mock→real swap for content + TTS) and **midday Day 2** (STT + quiz submit live), leaving Day-2 afternoon for the bug bash.

**Definition of Done (MVP):** all 8 requirements functional; Monlam TTS audible on vocab/listening; speaking scored via STT; quiz grades + awards XP; XP/level/streak persist in SQLite; clean responsive UI; seed script runs from empty DB.

---

## Next Step
On approval, we generate **module by module** in this order:
1. Backend scaffold + models + `database.py` + seed (Dev A)
2. Progress/XP service + endpoints (Dev A)
3. MonlamClient + speech/dictionary endpoints (Dev B)
4. Frontend scaffold + design system + api layer (Dev C/E)
5. Content pages (Alphabet, Lessons, Vocab) (Dev C)
6. Interactive exercises (Listening, Speaking, Quiz) (Dev D)
7. Progress/Result pages + integration + QA (Dev E)
```
