"""Pydantic DTOs for progress & XP endpoints."""
from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field


class LessonProgressOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    lesson_id: int
    status: str
    score_percent: int
    completed_at: datetime | None = None


class XPLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    source: str
    amount: int
    created_at: datetime


class ProgressOut(BaseModel):
    """Full profile snapshot for the single default user."""

    user_id: int
    display_name: str
    total_xp: int
    level: int
    xp_into_level: int
    xp_to_next_level: int
    streak_days: int
    last_active: date | None = None
    lessons: list[LessonProgressOut] = Field(default_factory=list)


class CompleteLessonIn(BaseModel):
    lesson_id: int
    score_percent: int = Field(default=100, ge=0, le=100)


class AwardXPIn(BaseModel):
    source: str = Field(examples=["vocab", "listening", "speaking", "quiz", "lesson"])
    amount: int = Field(gt=0)


class XPResultOut(BaseModel):
    """Returned after any XP-awarding action."""

    awarded_xp: int
    total_xp: int
    level: int
    leveled_up: bool
    xp_into_level: int
    xp_to_next_level: int
    streak_days: int
