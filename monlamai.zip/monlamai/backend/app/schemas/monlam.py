"""Pydantic DTOs for Monlam-backed speech / dictionary / translation endpoints."""
from pydantic import BaseModel, Field


# ── TTS ──
class TTSIn(BaseModel):
    text: str = Field(min_length=1, examples=["བཀྲ་ཤིས་བདེ་ལེགས"])


# ── STT ──
class STTOut(BaseModel):
    transcript: str
    confidence: float = Field(ge=0.0, le=1.0, default=0.0)


# ── Speaking score ──
class ScoreOut(BaseModel):
    is_correct: bool
    similarity: float = Field(ge=0.0, le=1.0)
    transcript: str
    expected_text: str
    confidence: float = Field(ge=0.0, le=1.0, default=0.0)


# ── Dictionary ──
class DictionaryEntry(BaseModel):
    word: str
    definitions: list[str] = Field(default_factory=list)
    pos: str | None = None  # part of speech


class DictionaryOut(BaseModel):
    word: str
    entries: list[DictionaryEntry] = Field(default_factory=list)
    source: str = "monlam"


# ── Translation ──
class TranslateIn(BaseModel):
    text: str = Field(min_length=1)
    src: str = Field(default="bo", examples=["bo", "en"])
    tgt: str = Field(default="en", examples=["en", "bo"])


class TranslateOut(BaseModel):
    text: str
    translation: str
    src: str
    tgt: str
