"""Application settings loaded from environment / .env file."""
from functools import lru_cache
from typing import List

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Monlam AI
    monlam_api_key: str = "changeme"
    monlam_base_url: str = "https://api.monlam.ai"

    # Database
    database_url: str = "sqlite:///./bodlingo.db"

    # CORS
    cors_origins: List[str] = ["http://localhost:5173", "http://127.0.0.1:5173"]

    # Media
    media_dir: str = "./media"

    # Seeding
    auto_seed: bool = True

    @field_validator("cors_origins", mode="before")
    @classmethod
    def split_cors(cls, v):
        """Allow comma-separated string in the .env file."""
        if isinstance(v, str):
            return [origin.strip() for origin in v.split(",") if origin.strip()]
        return v


@lru_cache
def get_settings() -> Settings:
    """Cached settings singleton."""
    return Settings()


settings = get_settings()
