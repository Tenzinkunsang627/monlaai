"""FastAPI application factory for BodLingo.

Module 1 sets up: app, CORS, error handlers, DB table creation, and
auto-seeding on startup. Routers are mounted in later modules.
"""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.core.errors import register_exception_handlers
from app.database import SessionLocal, create_all


@asynccontextmanager
async def lifespan(_: FastAPI):
    # Create tables on startup.
    create_all()

    # Auto-seed if enabled and DB is empty.
    if settings.auto_seed:
        from app.seed.seed_data import is_empty, seed_all

        db = SessionLocal()
        try:
            if is_empty(db):
                seed_all(db)
        finally:
            db.close()

    yield
    # (nothing to clean up on shutdown for the MVP)


def create_app() -> FastAPI:
    app = FastAPI(
        title="BodLingo API",
        description="Duolingo-style Tibetan learning app powered by Monlam AI.",
        version="0.1.0",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    register_exception_handlers(app)

    @app.get("/api/health", tags=["system"])
    def health():
        return {"status": "ok", "service": "bodlingo-api", "version": "0.1.0"}

    # Mounted routers
    from app.routers import (
        dictionary as dictionary_router,
        progress as progress_router,
        speech as speech_router,
    )

    app.include_router(progress_router.router, prefix="/api")
    app.include_router(speech_router.router, prefix="/api")
    app.include_router(dictionary_router.router, prefix="/api")

    # NOTE: remaining content/exercise/quiz routers are mounted in later modules:
    # from app.routers import alphabet, lessons, exercises, quiz
    # app.include_router(alphabet.router, prefix="/api")
    # ...

    return app


app = create_app()
