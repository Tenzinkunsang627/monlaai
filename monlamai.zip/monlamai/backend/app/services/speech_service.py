"""Speech logic: TTS caching and STT-based speaking scoring."""
from __future__ import annotations

import re
from difflib import SequenceMatcher

from app.core import audio_cache, xp_rules
from app.services import monlam_client


# ── TTS with disk cache ──────────────────────────────────────────────────────
async def get_tts_audio(text: str) -> bytes:
    """Return cached mp3 bytes if present, else fetch from Monlam and cache."""
    cached = audio_cache.get(text)
    if cached is not None:
        return cached
    audio = await monlam_client.tts(text)
    audio_cache.put(text, audio)
    return audio


# ── STT passthrough ──────────────────────────────────────────────────────────
async def transcribe(audio_bytes: bytes, filename: str, content_type: str) -> dict:
    return await monlam_client.stt(audio_bytes, filename=filename, content_type=content_type)


# ── Speaking scoring ─────────────────────────────────────────────────────────
_PUNCT = re.compile(r"[\s་།༎༏༐༑༆\.\,\!\?\-]+")


def normalize_tibetan(text: str) -> str:
    """Lowercase + strip Tibetan punctuation/tsheg and collapse whitespace."""
    if not text:
        return ""
    t = text.strip().lower()
    t = _PUNCT.sub("", t)
    return t


def similarity(a: str, b: str) -> float:
    na, nb = normalize_tibetan(a), normalize_tibetan(b)
    if not na and not nb:
        return 1.0
    if not na or not nb:
        return 0.0
    return SequenceMatcher(None, na, nb).ratio()


async def score_speaking(
    audio_bytes: bytes,
    expected_text: str,
    filename: str,
    content_type: str,
) -> dict:
    """Transcribe audio and compare against the expected Tibetan text."""
    stt = await monlam_client.stt(audio_bytes, filename=filename, content_type=content_type)
    transcript = stt.get("transcript", "")
    confidence = float(stt.get("confidence", 0.0) or 0.0)

    sim = similarity(transcript, expected_text)
    is_correct = sim >= xp_rules.STT_PASS_THRESHOLD

    return {
        "is_correct": is_correct,
        "similarity": round(sim, 3),
        "transcript": transcript,
        "expected_text": expected_text,
        "confidence": confidence,
    }
