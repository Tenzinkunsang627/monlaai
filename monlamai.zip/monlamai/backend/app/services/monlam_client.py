"""Async httpx wrapper for the Monlam AI APIs (TTS, STT, Dictionary, Translate).

The exact Monlam endpoint paths/response shapes may differ; this client isolates
those details behind typed methods and normalizes responses. Endpoint paths and
response parsing are centralized here so only this file changes if the API differs.

A MOCK mode is enabled automatically when MONLAM_API_KEY is unset/"changeme",
so the rest of the app (and the frontend) can be developed without live creds.
"""
from __future__ import annotations

import asyncio
import logging

import httpx

from app.config import settings
from app.core.errors import UpstreamError

logger = logging.getLogger("bodlingo.monlam")

# Endpoint paths (relative to MONLAM_BASE_URL). Adjust to match real API.
TTS_PATH = "/tts"
STT_PATH = "/stt"
DICTIONARY_PATH = "/dictionary"
TRANSLATE_PATH = "/translate"

_TIMEOUT = httpx.Timeout(30.0, connect=10.0)
_MAX_RETRIES = 2


def is_mock() -> bool:
    return not settings.monlam_api_key or settings.monlam_api_key == "changeme"


def _headers() -> dict[str, str]:
    return {"Authorization": f"Bearer {settings.monlam_api_key}"}


async def _request(method: str, path: str, **kwargs) -> httpx.Response:
    """Perform an HTTP request with basic retry/backoff and error wrapping."""
    url = settings.monlam_base_url.rstrip("/") + path
    last_exc: Exception | None = None
    for attempt in range(_MAX_RETRIES + 1):
        try:
            async with httpx.AsyncClient(timeout=_TIMEOUT, headers=_headers()) as client:
                resp = await client.request(method, url, **kwargs)
            if resp.status_code >= 500:
                raise UpstreamError(f"Monlam {path} returned {resp.status_code}")
            resp.raise_for_status()
            return resp
        except (httpx.HTTPError, UpstreamError) as exc:
            last_exc = exc
            if attempt < _MAX_RETRIES:
                await asyncio.sleep(0.5 * (attempt + 1))
            else:
                logger.warning("Monlam request failed: %s %s (%s)", method, url, exc)
    raise UpstreamError(f"Monlam request failed: {last_exc}")


# ── Public typed methods ────────────────────────────────────────────────────

async def tts(text: str) -> bytes:
    """Return audio bytes (mp3) for the given Tibetan text."""
    if is_mock():
        # Minimal silent-ish placeholder so the frontend audio flow works offline.
        return _mock_audio_bytes()
    resp = await _request("POST", TTS_PATH, json={"text": text})
    return resp.content


async def stt(audio_bytes: bytes, filename: str = "audio.webm", content_type: str = "audio/webm") -> dict:
    """Return {'transcript': str, 'confidence': float} from speech audio."""
    if is_mock():
        return {"transcript": "", "confidence": 0.0, "_mock": True}
    files = {"file": (filename, audio_bytes, content_type)}
    resp = await _request("POST", STT_PATH, files=files)
    data = resp.json()
    return {
        "transcript": data.get("transcript") or data.get("text", ""),
        "confidence": float(data.get("confidence", 0.0) or 0.0),
    }


async def dictionary(word: str) -> dict:
    """Return normalized dictionary entries for a word."""
    if is_mock():
        return {
            "word": word,
            "entries": [{"word": word, "definitions": ["(mock definition)"], "pos": None}],
            "source": "mock",
        }
    resp = await _request("GET", DICTIONARY_PATH, params={"word": word})
    data = resp.json()
    raw_entries = data.get("entries") or data.get("results") or []
    entries = [
        {
            "word": e.get("word", word),
            "definitions": e.get("definitions") or ([e["definition"]] if e.get("definition") else []),
            "pos": e.get("pos"),
        }
        for e in raw_entries
    ]
    return {"word": word, "entries": entries, "source": "monlam"}


async def translate(text: str, src: str, tgt: str) -> dict:
    """Translate text from src -> tgt language codes."""
    if is_mock():
        return {"text": text, "translation": f"[{tgt}] {text}", "src": src, "tgt": tgt}
    resp = await _request("POST", TRANSLATE_PATH, json={"text": text, "source": src, "target": tgt})
    data = resp.json()
    return {
        "text": text,
        "translation": data.get("translation") or data.get("text", ""),
        "src": src,
        "tgt": tgt,
    }


def _mock_audio_bytes() -> bytes:
    """A tiny valid MP3 frame header + silence, enough for a playable placeholder."""
    # 128-byte silent-ish payload; browsers will treat it as a very short clip.
    return b"\xff\xf3\x18\xc4" + b"\x00" * 124
