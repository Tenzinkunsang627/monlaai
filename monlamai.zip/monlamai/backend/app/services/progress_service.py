"""Business logic for XP awarding, level-ups, streaks, and lesson completion."""
from datetime import date, timedelta

from sqlalchemy.orm import Session

from app.core import xp_rules
from app.core.errors import NotFoundError
from app.repositories import progress_repo
from app.schemas.progress import (
    LessonProgressOut,
    ProgressOut,
    XPResultOut,
)


def _touch_streak(user) -> None:
    """Update the daily streak based on last_active vs today."""
    today = date.today()
    last = user.last_active

    if last == today:
        return  # already counted today
    if last == today - timedelta(days=1):
        user.streak_days += 1  # consecutive day
    else:
        user.streak_days = 1  # reset / first activity
    user.last_active = today


def _build_xp_result(user, awarded: int, prev_level: int) -> XPResultOut:
    return XPResultOut(
        awarded_xp=awarded,
        total_xp=user.total_xp,
        level=user.level,
        leveled_up=user.level > prev_level,
        xp_into_level=xp_rules.xp_into_level(user.total_xp),
        xp_to_next_level=xp_rules.xp_to_next_level(user.total_xp),
        streak_days=user.streak_days,
    )


def award_xp(db: Session, source: str, amount: int) -> XPResultOut:
    """Add XP, recompute level, update streak, and log the award."""
    user = progress_repo.get_or_create_default_user(db)
    prev_level = user.level

    user.total_xp += amount
    user.level = xp_rules.level_for_xp(user.total_xp)
    _touch_streak(user)
    progress_repo.update_user(db, user)

    progress_repo.add_xp_log(db, source=source, amount=amount)
    return _build_xp_result(user, amount, prev_level)


def complete_lesson(db: Session, lesson_id: int, score_percent: int) -> XPResultOut:
    """Mark a lesson completed and award the completion bonus (once)."""
    lesson = progress_repo.get_lesson(db, lesson_id)
    if lesson is None:
        raise NotFoundError(f"Lesson {lesson_id} not found")

    existing = progress_repo.get_progress(db, lesson_id)
    already_completed = existing is not None and existing.status == "completed"

    progress_repo.upsert_progress(
        db,
        lesson_id=lesson_id,
        status="completed",
        score_percent=score_percent,
        completed=True,
    )

    bonus = 0 if already_completed else xp_rules.XP_LESSON_COMPLETE_BONUS
    if bonus:
        return award_xp(db, source="lesson", amount=bonus)

    # No new XP (re-completion): still return a current snapshot.
    user = progress_repo.get_or_create_default_user(db)
    return _build_xp_result(user, 0, user.level)


def get_progress(db: Session) -> ProgressOut:
    """Full profile snapshot for the default user."""
    user = progress_repo.get_or_create_default_user(db)
    lessons = [
        LessonProgressOut.model_validate(p) for p in progress_repo.list_progress(db)
    ]
    return ProgressOut(
        user_id=user.id,
        display_name=user.display_name,
        total_xp=user.total_xp,
        level=user.level,
        xp_into_level=xp_rules.xp_into_level(user.total_xp),
        xp_to_next_level=xp_rules.xp_to_next_level(user.total_xp),
        streak_days=user.streak_days,
        last_active=user.last_active,
        lessons=lessons,
    )


def get_xp_log(db: Session, limit: int = 20):
    return progress_repo.list_xp_log(db, limit=limit)
