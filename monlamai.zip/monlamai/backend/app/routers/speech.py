"""Speech endpoints: TTS, STT, and speaking-score (Monlam-backed)."""
from fastapi import APIRouter, File, Form, UploadFile
from fastapi.responses import Response

from app.schemas.monlam import ScoreOut, STTOut, TTSIn
from app.services import speech_service

router = APIRouter(prefix="/speech", tags=["speech"])


@router.post(
    "/tts",
    responses={200: {"content": {"audio/mpeg": {}}}},
    response_class=Response,
)
async def text_to_speech(payload: TTSIn) -> Response:
    """Return mp3 audio for the given Tibetan text (cached on disk)."""
    audio = await speech_service.get_tts_audio(payload.text)
    return Response(
        content=audio,
        media_type="audio/mpeg",
        headers={"Cache-Control": "public, max-age=86400"},
    )


@router.post("/stt", response_model=STTOut)
async def speech_to_text(file: UploadFile = File(...)) -> STTOut:
    """Transcribe uploaded speech audio to Tibetan text."""
    data = await file.read()
    result = await speech_service.transcribe(
        data, filename=file.filename or "audio.webm", content_type=file.content_type or "audio/webm"
    )
    return STTOut(transcript=result.get("transcript", ""), confidence=result.get("confidence", 0.0))


@router.post("/score", response_model=ScoreOut)
async def score_speaking(
    expected_text: str = Form(...),
    file: UploadFile = File(...),
) -> ScoreOut:
    """Score a speaking attempt against the expected Tibetan text."""
    data = await file.read()
    result = await speech_service.score_speaking(
        audio_bytes=data,
        expected_text=expected_text,
        filename=file.filename or "audio.webm",
        content_type=file.content_type or "audio/webm",
    )
    return ScoreOut(**result)
