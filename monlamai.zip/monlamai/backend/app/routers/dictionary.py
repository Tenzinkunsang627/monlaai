"""Dictionary & translation endpoints (Monlam-backed)."""
from fastapi import APIRouter, Query

from app.schemas.monlam import DictionaryOut, TranslateIn, TranslateOut
from app.services import monlam_client

router = APIRouter(tags=["dictionary"])


@router.get("/dictionary", response_model=DictionaryOut)
async def lookup(word: str = Query(..., min_length=1)) -> DictionaryOut:
    """Look up a word in the Monlam dictionary."""
    data = await monlam_client.dictionary(word)
    return DictionaryOut(**data)


@router.post("/translate", response_model=TranslateOut)
async def translate(payload: TranslateIn) -> TranslateOut:
    """Translate text between Tibetan (bo) and English (en)."""
    data = await monlam_client.translate(payload.text, payload.src, payload.tgt)
    return TranslateOut(**data)
