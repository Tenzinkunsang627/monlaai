"""Progress & XP endpoints for the single default user."""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.progress import (
    AwardXPIn,
    CompleteLessonIn,
    ProgressOut,
    XPLogOut,
    XPResultOut,
)
from app.services import progress_service

router = APIRouter(prefix="/progress", tags=["progress"])


@router.get("", response_model=ProgressOut)
def read_progress(db: Session = Depends(get_db)) -> ProgressOut:
    """Full profile: total XP, level, streak, and per-lesson status."""
    return progress_service.get_progress(db)


@router.post("/complete", response_model=XPResultOut)
def complete_lesson(
    payload: CompleteLessonIn, db: Session = Depends(get_db)
) -> XPResultOut:
    """Mark a lesson complete and award the completion bonus (once)."""
    return progress_service.complete_lesson(
        db, lesson_id=payload.lesson_id, score_percent=payload.score_percent
    )


@router.post("/award", response_model=XPResultOut)
def award_xp(payload: AwardXPIn, db: Session = Depends(get_db)) -> XPResultOut:
    """Award XP from an exercise/quiz action (updates level & streak)."""
    return progress_service.award_xp(db, source=payload.source, amount=payload.amount)


@router.get("/xp-log", response_model=list[XPLogOut])
def read_xp_log(
    limit: int = Query(default=20, ge=1, le=100),
    db: Session = Depends(get_db),
) -> list[XPLogOut]:
    """Recent XP history (most recent first)."""
    return progress_service.get_xp_log(db, limit=limit)
