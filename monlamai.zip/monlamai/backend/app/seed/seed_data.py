"""Idempotent seed loader: loads JSON fixtures into the database.

Run standalone:  python -m app.seed.seed_data
Or call seed_all(db) from app startup.
"""
import json
from datetime import datetime
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database import SessionLocal, create_all
from app.models import (
    Alphabet,
    Lesson,
    Option,
    Question,
    Quiz,
    User,
    Vocabulary,
)

SEED_DIR = Path(__file__).parent


def _load_json(name: str):
    with open(SEED_DIR / name, encoding="utf-8") as f:
        return json.load(f)


def _seed_default_user(db: Session) -> None:
    if db.get(User, 1) is None:
        db.add(User(id=1, display_name="Learner", created_at=datetime.utcnow()))
        db.commit()


def _seed_alphabet(db: Session) -> None:
    if db.scalar(select(Alphabet).limit(1)) is not None:
        return
    for row in _load_json("alphabet.json"):
        db.add(Alphabet(**row))
    db.commit()


def _seed_vocabulary(db: Session) -> dict[str, Lesson]:
    """Seed lessons + vocabulary. Returns a map of lesson title -> Lesson."""
    lessons_by_title: dict[str, Lesson] = {}

    existing = {l.title: l for l in db.scalars(select(Lesson)).all()}
    if existing:
        return existing

    for entry in _load_json("vocabulary.json"):
        meta = entry["lesson"]
        lesson = Lesson(
            title=meta["title"],
            description=meta.get("description"),
            category=meta.get("category", "vocabulary"),
            level=meta.get("level", 1),
            order_index=meta.get("order_index", 0),
            icon=meta.get("icon"),
        )
        db.add(lesson)
        db.flush()  # get lesson.id
        for w in entry["words"]:
            db.add(Vocabulary(lesson_id=lesson.id, **w))
        lessons_by_title[lesson.title] = lesson

    db.commit()
    return lessons_by_title


def _seed_quizzes(db: Session, lessons_by_title: dict[str, Lesson]) -> None:
    if db.scalar(select(Quiz).limit(1)) is not None:
        return

    # ensure we have a fresh lookup if lessons already existed
    if not lessons_by_title:
        lessons_by_title = {l.title: l for l in db.scalars(select(Lesson)).all()}

    for entry in _load_json("quizzes.json"):
        qmeta = entry["quiz"]
        lesson = lessons_by_title.get(qmeta.get("lesson_title", ""))
        quiz = Quiz(
            title=qmeta["title"],
            lesson_id=lesson.id if lesson else None,
            xp_reward=qmeta.get("xp_reward", 20),
        )
        db.add(quiz)
        db.flush()
        for q in entry["questions"]:
            question = Question(
                quiz_id=quiz.id,
                type=q.get("type", "mcq"),
                prompt=q["prompt"],
                prompt_audio=q.get("prompt_audio"),
                order_index=q.get("order_index", 0),
            )
            db.add(question)
            db.flush()
            for opt in q["options"]:
                db.add(
                    Option(
                        question_id=question.id,
                        text=opt["text"],
                        is_correct=bool(opt.get("is_correct", False)),
                    )
                )
    db.commit()


def seed_all(db: Session) -> None:
    """Seed everything idempotently (safe to call repeatedly)."""
    _seed_default_user(db)
    _seed_alphabet(db)
    lessons_by_title = _seed_vocabulary(db)
    _seed_quizzes(db, lessons_by_title)


def is_empty(db: Session) -> bool:
    """True if no lessons exist yet (used to decide auto-seed on startup)."""
    return db.scalar(select(Lesson).limit(1)) is None


def main() -> None:
    create_all()
    db = SessionLocal()
    try:
        seed_all(db)
        print("✅ Seed complete.")
    finally:
        db.close()


if __name__ == "__main__":
    main()
