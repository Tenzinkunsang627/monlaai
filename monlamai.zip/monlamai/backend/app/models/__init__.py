"""Import all models so SQLAlchemy registers them on Base.metadata."""
from app.models.user import User
from app.models.alphabet import Alphabet
from app.models.lesson import Lesson, Vocabulary
from app.models.exercise import Exercise
from app.models.quiz import Quiz, Question, Option
from app.models.progress import UserProgress, ExerciseAttempt, XPLog

__all__ = [
    "User",
    "Alphabet",
    "Lesson",
    "Vocabulary",
    "Exercise",
    "Quiz",
    "Question",
    "Option",
    "UserProgress",
    "ExerciseAttempt",
    "XPLog",
]
