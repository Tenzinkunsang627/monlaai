"""Lesson and Vocabulary models."""
from sqlalchemy import ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


class Lesson(Base):
    __tablename__ = "lessons"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[str | None] = mapped_column(String, nullable=True)
    category: Mapped[str] = mapped_column(String, default="vocabulary")  # vocabulary | listening | speaking
    level: Mapped[int] = mapped_column(Integer, default=1)
    order_index: Mapped[int] = mapped_column(Integer, default=0)
    icon: Mapped[str | None] = mapped_column(String, nullable=True)

    # relationships
    vocabulary = relationship(
        "Vocabulary", back_populates="lesson", cascade="all, delete-orphan",
        order_by="Vocabulary.order_index",
    )
    exercises = relationship(
        "Exercise", back_populates="lesson", cascade="all, delete-orphan",
        order_by="Exercise.order_index",
    )
    quizzes = relationship("Quiz", back_populates="lesson", cascade="all, delete-orphan")


class Vocabulary(Base):
    __tablename__ = "vocabulary"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    lesson_id: Mapped[int] = mapped_column(ForeignKey("lessons.id"), nullable=False)
    tibetan: Mapped[str] = mapped_column(String, nullable=False)
    romanization: Mapped[str | None] = mapped_column(String, nullable=True)
    english: Mapped[str] = mapped_column(String, nullable=False)
    audio_url: Mapped[str | None] = mapped_column(String, nullable=True)
    order_index: Mapped[int] = mapped_column(Integer, default=0)

    lesson = relationship("Lesson", back_populates="vocabulary")
