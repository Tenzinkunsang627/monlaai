"""Tibetan alphabet (consonants + vowels) model."""
from sqlalchemy import Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


class Alphabet(Base):
    __tablename__ = "alphabet"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    char: Mapped[str] = mapped_column(String, nullable=False)
    romanization: Mapped[str] = mapped_column(String, nullable=False)
    ipa: Mapped[str | None] = mapped_column(String, nullable=True)
    type: Mapped[str] = mapped_column(String, default="consonant")  # consonant | vowel
    order_index: Mapped[int] = mapped_column(Integer, default=0)
    example_word: Mapped[str | None] = mapped_column(String, nullable=True)
    example_meaning: Mapped[str | None] = mapped_column(String, nullable=True)
