"""Exercise model (listening / speaking / match)."""
from sqlalchemy import ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


class Exercise(Base):
    __tablename__ = "exercises"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    lesson_id: Mapped[int] = mapped_column(ForeignKey("lessons.id"), nullable=False)
    type: Mapped[str] = mapped_column(String, default="listening")  # listening | speaking | match
    prompt_tibetan: Mapped[str | None] = mapped_column(String, nullable=True)
    prompt_english: Mapped[str | None] = mapped_column(String, nullable=True)
    expected_text: Mapped[str | None] = mapped_column(String, nullable=True)  # STT target
    xp_reward: Mapped[int] = mapped_column(Integer, default=10)
    order_index: Mapped[int] = mapped_column(Integer, default=0)

    lesson = relationship("Lesson", back_populates="exercises")
