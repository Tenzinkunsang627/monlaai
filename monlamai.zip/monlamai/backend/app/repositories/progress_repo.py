"""Data-access layer for progress, XP, and the default user."""
from datetime import datetime

from sqlalchemy import desc, select
from sqlalchemy.orm import Session

from app.models import Lesson, User, UserProgress, XPLog

DEFAULT_USER_ID = 1


def get_user(db: Session, user_id: int = DEFAULT_USER_ID) -> User | None:
    return db.get(User, user_id)


def get_or_create_default_user(db: Session) -> User:
    user = db.get(User, DEFAULT_USER_ID)
    if user is None:
        user = User(id=DEFAULT_USER_ID, display_name="Learner", created_at=datetime.utcnow())
        db.add(user)
        db.commit()
        db.refresh(user)
    return user


def update_user(db: Session, user: User) -> User:
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def get_lesson(db: Session, lesson_id: int) -> Lesson | None:
    return db.get(Lesson, lesson_id)


def list_progress(db: Session, user_id: int = DEFAULT_USER_ID) -> list[UserProgress]:
    return list(
        db.scalars(select(UserProgress).where(UserProgress.user_id == user_id)).all()
    )


def get_progress(
    db: Session, lesson_id: int, user_id: int = DEFAULT_USER_ID
) -> UserProgress | None:
    return db.scalar(
        select(UserProgress).where(
            UserProgress.user_id == user_id,
            UserProgress.lesson_id == lesson_id,
        )
    )


def upsert_progress(
    db: Session,
    lesson_id: int,
    status: str,
    score_percent: int,
    user_id: int = DEFAULT_USER_ID,
    completed: bool = False,
) -> UserProgress:
    progress = get_progress(db, lesson_id, user_id)
    if progress is None:
        progress = UserProgress(user_id=user_id, lesson_id=lesson_id)
        db.add(progress)
    progress.status = status
    progress.score_percent = score_percent
    if completed:
        progress.completed_at = datetime.utcnow()
    db.commit()
    db.refresh(progress)
    return progress


def add_xp_log(
    db: Session, source: str, amount: int, user_id: int = DEFAULT_USER_ID
) -> XPLog:
    entry = XPLog(user_id=user_id, source=source, amount=amount, created_at=datetime.utcnow())
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry


def list_xp_log(
    db: Session, limit: int = 20, user_id: int = DEFAULT_USER_ID
) -> list[XPLog]:
    return list(
        db.scalars(
            select(XPLog)
            .where(XPLog.user_id == user_id)
            .order_by(desc(XPLog.created_at))
            .limit(limit)
        ).all()
    )
