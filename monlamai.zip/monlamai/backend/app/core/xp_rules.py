"""XP awarding rules and level thresholds (single source of truth)."""

# XP rewards per action source
XP_VOCAB_VIEWED = 2
XP_LISTENING_CORRECT = 10
XP_SPEAKING_CORRECT = 15
XP_QUIZ_QUESTION_CORRECT = 5
XP_LESSON_COMPLETE_BONUS = 20

# One level per this many XP.
XP_PER_LEVEL = 100

# Speaking similarity threshold to count as "correct".
STT_PASS_THRESHOLD = 0.70


def level_for_xp(total_xp: int) -> int:
    """Return the 1-based level for a given total XP."""
    if total_xp < 0:
        total_xp = 0
    return total_xp // XP_PER_LEVEL + 1


def xp_into_level(total_xp: int) -> int:
    """XP accumulated within the current level."""
    return total_xp % XP_PER_LEVEL


def xp_to_next_level(total_xp: int) -> int:
    """XP remaining until the next level."""
    return XP_PER_LEVEL - xp_into_level(total_xp)
