"""Disk cache for TTS audio: hash(text) -> mp3 file under MEDIA_DIR/tts_cache."""
import hashlib
from pathlib import Path

from app.config import settings

CACHE_DIR = Path(settings.media_dir) / "tts_cache"


def _ensure_dir() -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)


def key_for(text: str) -> str:
    """Stable filename key for a given text."""
    digest = hashlib.sha256(text.strip().encode("utf-8")).hexdigest()[:32]
    return f"{digest}.mp3"


def path_for(text: str) -> Path:
    return CACHE_DIR / key_for(text)


def get(text: str) -> bytes | None:
    p = path_for(text)
    if p.exists():
        return p.read_bytes()
    return None


def put(text: str, data: bytes) -> Path:
    _ensure_dir()
    p = path_for(text)
    p.write_bytes(data)
    return p
