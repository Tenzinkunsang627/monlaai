# BodLingo — Backend

FastAPI + SQLAlchemy + SQLite backend for the BodLingo Tibetan learning app.

## Setup

```bash
cd backend
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
# source .venv/bin/activate

pip install -r requirements.txt
copy .env.example .env        # Windows  (cp .env.example .env on macOS/Linux)
```

## Seed the database

Tables are created and seeded automatically on server startup (`AUTO_SEED=true`).
To seed manually from an empty DB:

```bash
python -m app.seed.seed_data
```

## Run the API

```bash
# Recommended (works even if the uvicorn.exe script isn't on PATH):
python -m uvicorn app.main:app --reload --port 8000
```
> On Windows, if `uvicorn` isn't recognized, always use `python -m uvicorn ...`.

- Health check: http://localhost:8000/api/health
- Swagger docs: http://localhost:8000/docs

## Module 1 status (this commit)

Scaffold complete:
- `config.py`, `database.py`, all ORM `models/`
- `core/` (XP rules, error handlers)
- `seed/` (alphabet, vocabulary, quizzes JSON + idempotent loader)
- `main.py` app factory with CORS, error handlers, startup create+seed, `/api/health`

Routers/services/repositories are added in later modules.
